﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MultiplexManagement.Models;

namespace MultiplexManagement.Models
{
    public class MultiplexManagementContext : DbContext
    {
        public MultiplexManagementContext (DbContextOptions<MultiplexManagementContext> options)
            : base(options)
        {
        }

        public DbSet<MultiplexManagement.Models.City> City { get; set; }

        public DbSet<MultiplexManagement.Models.Multiplex> Multiplex { get; set; }

        public DbSet<MultiplexManagement.Models.Movie> Movie { get; set; }

        public DbSet<MultiplexManagement.Models.User> User { get; set; }

        public DbSet<MultiplexManagement.Models.Booking> Booking { get; set; }
    }
}
