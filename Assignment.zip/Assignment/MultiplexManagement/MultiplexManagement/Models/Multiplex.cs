﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MultiplexManagement.Models
{
    public class Multiplex
    {
        public int MultiplexID { get; set; }

        public string MultiplexName { get; set; }

        [Range(1,100,ErrorMessage ="Multiplex can have maximum 100 seats")]
        public int TotalSeats { get; set; }

        public City City { get; set; }
    }
}
