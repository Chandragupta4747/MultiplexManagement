﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MultiplexManagement.Models
{
    public class Booking
    {
        public int BookingID { get; set; }

        public DateTime BookingDate { get; set; }

        public User User { get; set; }

        public Multiplex Multiplex { get; set; }

        public Movie Movie { get; set; }

        [Range(1, 5, ErrorMessage = "Customer is not allowed to book more than 5 tickets")]
        public int TotalBookSeats { get; set; }
    }
}
