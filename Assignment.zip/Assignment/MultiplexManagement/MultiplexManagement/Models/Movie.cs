﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiplexManagement.Models
{
    public class Movie
    {
        public int MovieID { get; set; }

        public string MovieName { get; set; }

        public string Genres { get; set; }

        public string Languages { get; set; }

        public Multiplex Multiplex { get; set; }
    }
}
