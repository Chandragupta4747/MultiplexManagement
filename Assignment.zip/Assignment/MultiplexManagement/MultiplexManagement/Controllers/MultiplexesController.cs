﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MultiplexManagement.Models;

namespace MultiplexManagement.Controllers
{
    [Route("api/[controller]")]

    //[Authorize(Roles = "Admin")]

    //[Authorize(Roles = "Admin")]
      
    [ApiController]
    public class MultiplexesController : ControllerBase
    {

        private readonly MultiplexManagementContext _context;

       
        public MultiplexesController(MultiplexManagementContext context)
        {
            _context = context;
        }


        // GET: api/Multiplexes
        //[Authorize(Roles = "Admin")]
        [HttpGet]
        public IEnumerable<Multiplex> GetMultiplex()
        {
            return _context.Multiplex;
        }

        // GET: api/Multiplexes/5
        //[Authorize(Roles = "Admin")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetMultiplex([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var multiplex = await _context.Multiplex.FindAsync(id);

            if (multiplex == null)
            {
                return NotFound();
            }

            return Ok(multiplex);
        }

        // PUT: api/Multiplexes/5
        //[Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> PutMultiplex([FromRoute] int id, [FromBody] Multiplex multiplex)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != multiplex.MultiplexID)
            {
                return BadRequest();
            }

            _context.Entry(multiplex).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MultiplexExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Multiplexes
        //[Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> PostMultiplex([FromBody] Multiplex multiplex)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.Multiplex.Add(multiplex);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetMultiplex", new { id = multiplex.MultiplexID }, multiplex);
        }

        // DELETE: api/Multiplexes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMultiplex([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var multiplex = await _context.Multiplex.FindAsync(id);
            if (multiplex == null)
            {
                return NotFound();
            }

            _context.Multiplex.Remove(multiplex);
            await _context.SaveChangesAsync();

            return Ok(multiplex);
        }

        private bool MultiplexExists(int id)
        {
            return _context.Multiplex.Any(e => e.MultiplexID == id);
        }
    }
}